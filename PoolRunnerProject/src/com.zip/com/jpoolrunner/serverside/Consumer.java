package com.jpoolrunner.serverside;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.swing.JTextArea;

import com.jpoolrunner.TPSInterface.TPSInterface;
import com.jpoolrunner.job.Task;

public class Consumer extends Thread {
	private BlockingQueue<Runnable> tempQueue=null;
	TPSInterface strategy=null;
	SharedBoolean sharedBoolean;
	SharedBoolean sharedBoolean2;
	boolean flag=false;
	RecieverCounter recieverCounter;
	RecieverHelperCounter recieverHelperCounter;
	JTextArea textArea;

	public Consumer(BlockingQueue<Runnable> tempQueue,SharedBoolean sharedBoolean,SharedBoolean sharedBoolean2,RecieverCounter recieverCounter,RecieverHelperCounter recieverHelperCounter, JTextArea textArea) {
		this.sharedBoolean=sharedBoolean;
		this.sharedBoolean2=sharedBoolean2;
		this.tempQueue = tempQueue;
		this.recieverCounter=recieverCounter;
		this.recieverHelperCounter=recieverHelperCounter;
		this.textArea=textArea;
		//this.strategy=strategy;
	}
	public void setStrategy(TPSInterface strategy){
		this.strategy=strategy;
	}
 public void run(){
		//textArea.append("\nRecieverHelper has started");

	 try{
	 do{
			if (!tempQueue.isEmpty() ){	
				Runnable jobx=(Runnable)tempQueue.take();
				//long time=System.currentTimeMillis();
				long timeNano=System.nanoTime();

				Task pj=(Task)jobx;
			//	pj.setReciveTime(time);	
				pj.setNanoReciveTime(timeNano);
			//	pj.setA(time);
				Runnable r=(Runnable)pj;
				this.strategy.submitRequest(r);
				this.recieverHelperCounter.increment();


				}
			else if(tempQueue.isEmpty()&& this.sharedBoolean.getStopValue()==true ){ 
				if(this.recieverCounter.getCounter()==this.recieverHelperCounter.getCounter())
				
				{
				//	textArea.append("RecievrCounter="+recieverCounter.getCounter()+" RsvrHelperCounter="+recieverHelperCounter.getCounter());
				
				flag=true;	
				break;
				}
				/*synchronized(stop){
					if(stop==true) break; 
					}*/
				
			}
		//	Thread.sleep(100);
			}while(true);
	 }catch(Exception e){
		 textArea.append("\ni m in Consumer");
	 }
	 finally{
			//textArea.append("\nRecieverHelper has stopped");
			if(flag) this.sharedBoolean2.setStopValue(true);//ie ResponSednder should stop 
		}
 }

}
